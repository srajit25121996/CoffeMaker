package com.cognizant.coffee;

import java.time.chrono.IsoChronology;
import java.util.ArrayList;

public class RecipeBook {

	
	/**/
	private ArrayList<Recipe> rList;
	
	public RecipeBook(){
		
		rList=new ArrayList<>();
	}
	
	public boolean addRecipe(Recipe recipe){
		boolean flag ;
		
		for(Recipe R: rList){
			if(R.equals(recipe)){
				return false;
			}
			
		}
		
		
		flag=rList.add(recipe);
		return flag;
		
	}
	
	
	
	public void showRecipes(){
		for(Recipe R:rList){
			System.out.println(R);
		}
	}
	
	public boolean deleteRecipe(String rname){
		boolean flag=false;
		for(Recipe R: rList){
			if(R.getName().equals(rname)){
				rList.remove(R);
				return true;
			}
			
		}
		return false;
	}
	
}
