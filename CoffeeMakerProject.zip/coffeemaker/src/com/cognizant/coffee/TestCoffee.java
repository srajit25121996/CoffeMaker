package com.cognizant.coffee;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;


public class TestCoffee {
	
	
	public static void  showMenu(){
	          
              System.out.println("******Enter Your Choice*****");
              System.out.println("1.Add Recipe");
              System.out.println("2. Remove Recipe");
              System.out.println("3. Show Recipes");
              System.out.println("4. Exit");
         }
	
	public static Recipe inputRecipe() throws RecipeException{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String m_name=null;
		String m_price=null;
		String m_amtCoffee=null;
		String m_amtchocolate=null;
		String m_amtMilk=null;
		System.out.println("Enter name, Price, AmtCoffee, AmtChocolate,AmtMilk");
		String input=null;
		 try {
			input=br.readLine();
			String sArr[]=input.split(" ");
			m_name=sArr[0];
			m_price=sArr[1];
			m_amtCoffee=sArr[2];
			m_amtchocolate=sArr[3];
			m_amtMilk=sArr[4];
		
		 } 
		 
		 catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 Recipe recipe=new Recipe();
		 recipe.setName(m_name);
		recipe.setPrice(m_price);
		recipe.setAmtChocolate(m_amtchocolate);
		recipe.setAmtCoffee(m_amtCoffee);
		recipe.setAmtMilk(m_amtMilk);
		
		 return recipe;
		
	}
	
	
	

	public static void main(String[] args) throws RecipeException {
		// TODO Auto-generated method stub
		System.out.println("----------------Welcome To Coffee Maker-----------------");
		 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
         String  response;
         char choice;
         RecipeBook rbook=new RecipeBook();
         while(true){
        	 showMenu();
        	 try {
				choice=(br.readLine()).charAt(0);
				switch (choice) {
				case '1':
					
					Recipe r1=inputRecipe();
					
					if(rbook.addRecipe(r1)){
						System.out.println("Recipe Added");
					}
					else{
						System.out.println("Recipe Not Added");
					}
					
					 break;
                case '2':
				
                	System.out.println("Enter The Coffee Name To Be Delete : ");
                	
                	String c_name=br.readLine();
                	
                	
                	if(rbook.deleteRecipe(c_name)){
                		System.out.println("Coffee Deleted Successfully");
                	}
                	else{
                		System.out.println("---------Coffee Name Does Not Present------");
                	}
                	
                       break;

                case '3':
                	
                	rbook.showRecipes();
	
                	
                	
	                   break;
                case '4':
                	System.out.println("-------------Thank You For Using Coffee Maker-----------");
                         System.exit(0);
	                   

				
				}
				/*System.out.println("@@@@--DO YOU WISH TO CONTINUE--@@@@");
				response=br.readLine();
				if(response.equalsIgnoreCase("N")){
					
				}*/
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		   }	 
        }
	}
}
