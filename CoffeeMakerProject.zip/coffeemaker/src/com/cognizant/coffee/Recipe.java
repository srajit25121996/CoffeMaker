package com.cognizant.coffee;

public class Recipe {
	private String name;
	private int price;
	private int amtCoffee,amtMilk,amtChocolate;
	
	public Recipe(String name, int price, int amtCoffee, int amtMilk, int amtChocolate) {
		super();
		this.name = name;
		this.price = price;
		this.amtCoffee = amtCoffee;
		this.amtMilk = amtMilk;
		this.amtChocolate = amtChocolate;
	}
	public Recipe() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	//override     tostring methods 
	@Override
	public String toString() {
		return "Recipe     name=" + name + ", price=" + price + ", amtCoffee=" + amtCoffee + ", amtMilk=" + amtMilk
				+ ", amtChocolate=" + amtChocolate + "";
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + amtChocolate;
		result = prime * result + amtCoffee;
		result = prime * result + amtMilk;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + price;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Recipe other = (Recipe) obj;
		if (amtChocolate != other.amtChocolate)
			return false;
		if (amtCoffee != other.amtCoffee)
			return false;
		if (amtMilk != other.amtMilk)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (price != other.price)
			return false;
		return true;
	}
	
	
	
	//name
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	//Price
	
	public int getPrice() {
		return price;
	}
	public void setPrice(String  c_price)  throws RecipeException {
		
		int price=0;
		try
		{	
			price=Integer.parseInt(c_price);
		}
		catch(NumberFormatException e){
			throw new RecipeException("Price should be greater than or equal to : 0");
		}
		if(price>=0){
			this.price = price;
			
		}
		else{
			throw new RecipeException("Price should be greater than or equal to : 0");
		}
		
		
	
	}
	
	
	
	//coffee
	
	
	public int getAmtCoffee() {
		return amtCoffee;
	}
	public void setAmtCoffee(String coffee)   throws RecipeException {
		
		int amtcoffee=0;
		try
		{	
			amtCoffee=Integer.parseInt(coffee);
		}
		catch(NumberFormatException e){
			throw new RecipeException("Unit of coffe must be positive integer");
		}
		if(amtcoffee>=0){
			this.amtCoffee = amtCoffee;
			
		}
		else{
			throw new RecipeException("Unit of coffees must be positive integer");
		}
		
		
	}
	
	
	//milk
	
	
	public int getAmtMilk() {
		return amtMilk;
	}
	public void setAmtMilk (String Milk)  throws RecipeException{
		
		
		int amtMilk=0;
		try
		{	
			amtMilk=Integer.parseInt(Milk);
		}
		catch(NumberFormatException e){
			throw new RecipeException("Unit of Milk must be positive integer");
		}
		if(amtMilk>=0){
			this.amtMilk = amtMilk;
			
		}
		else{
			throw new RecipeException("Unit of Milk must be positive integer");
		}
		
		
	}
	
	
	//Amount chocolate
	
	
	public int getAmtChocolate() {
		return amtChocolate;
	}
	public void setAmtChocolate(String chocolate) throws RecipeException {
		
		int amtChocolate=0;
		try
		{	
			amtChocolate=Integer.parseInt(chocolate);
		}
		catch(NumberFormatException e){
			throw new RecipeException("Unit of Chocolates must be positive integer");
		}
		if(amtChocolate>=0){
			this.amtChocolate=amtChocolate;
			
		}
		else{
			throw new RecipeException("Unit of Chocolates must be positive integer");
		}
		
		
		//this.amtChocolate = amtChocolate;
	}
	}
