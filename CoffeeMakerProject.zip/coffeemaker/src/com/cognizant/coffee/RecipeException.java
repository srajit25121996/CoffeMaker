package com.cognizant.coffee;

public class RecipeException extends Exception {
	public RecipeException(String msg){
		super(msg);
	}

}


